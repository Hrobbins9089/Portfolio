# W1D4 - Activity 02: CSS Positioning

## W1D4 - Activity 02: CSS Positioning

* In this activity you will be placing HTML elements on a page using the CSS positioning property.

* **Files:**

    * `04-CSSPositionedActivity/Unsolved/positioning.html`

* **Instructions:**

   * Create a file called `positioning.html` and a file called `positioning.css`.

   * Using HTML/CSS, create the layout shown on the screen.

   * For reference, the colors used on the screen are `#eee` and `#999`.